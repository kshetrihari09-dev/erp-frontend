declare module 'html2pdf.js' {
  interface Html2PdfOptions {
    margin?: number | [number, number, number, number]
    filename?: string
    image?: { type?: string; quality?: number }
    html2canvas?: Record<string, unknown>
    jsPDF?: Record<string, unknown>
  }

  interface Html2PdfInstance {
    set: (opt: Html2PdfOptions) => Html2PdfInstance
    from: (element: HTMLElement) => Html2PdfInstance
    save: () => Promise<void>
    outputPdf: (type: 'blob' | 'datauristring' | string) => Promise<Blob | string>
  }

  function html2pdf(): Html2PdfInstance
  export default html2pdf
}
